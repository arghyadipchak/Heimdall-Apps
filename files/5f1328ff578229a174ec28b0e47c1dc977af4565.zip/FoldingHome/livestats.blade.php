<ul class="livestats">
    <li>
        <span class="title">{{ $status }}</span>
        <strong>{!! $progress !!}</strong>
    </li>
    <li>
        <span class="title">ETA</span>
        <strong>{!! $eta !!}</strong>
    </li>
</ul>
