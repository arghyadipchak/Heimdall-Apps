<?php namespace App\SupportedApps\RompЯ;

class RompЯ extends \App\SupportedApps {

}