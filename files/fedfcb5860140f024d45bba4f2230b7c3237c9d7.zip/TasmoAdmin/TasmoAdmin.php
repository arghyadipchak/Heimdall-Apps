<?php namespace App\SupportedApps\TasmoAdmin;

class TasmoAdmin extends \App\SupportedApps {

}