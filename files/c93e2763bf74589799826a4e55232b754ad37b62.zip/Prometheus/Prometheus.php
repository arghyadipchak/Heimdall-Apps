<?php namespace App\SupportedApps\Prometheus;

class Prometheus extends \App\SupportedApps {

}