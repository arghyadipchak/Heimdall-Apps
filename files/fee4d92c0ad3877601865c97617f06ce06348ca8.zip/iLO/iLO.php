<?php namespace App\SupportedApps\iLO;

class iLO extends \App\SupportedApps {

}
