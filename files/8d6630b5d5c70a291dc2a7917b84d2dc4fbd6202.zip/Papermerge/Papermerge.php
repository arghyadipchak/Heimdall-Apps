<?php namespace App\SupportedApps\Papermerge;

class Papermerge extends \App\SupportedApps {

}