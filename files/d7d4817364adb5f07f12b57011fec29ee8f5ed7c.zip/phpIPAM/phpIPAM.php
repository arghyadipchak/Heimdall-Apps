<?php namespace App\SupportedApps\phpIPAM;

class phpIPAM extends \App\SupportedApps {

}