<ul class="livestats">
    <li>
        <span class="title">Missing</span>
        <strong>{!! $missing !!}</strong>
    </li>
</ul>
