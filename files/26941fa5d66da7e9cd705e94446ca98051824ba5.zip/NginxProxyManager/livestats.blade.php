<ul class="livestats">
    <li>
        <span class="title">Proxy Hosts</span>
        <strong>{!! $proxy !!}</strong>
    </li>
    <li>
        <span class="title">Redirection Hosts</span>
        <strong>{!! $redirection !!}</strong>
    </li>
</ul>
