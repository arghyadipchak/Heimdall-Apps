<ul class="livestats">
    <li>
        <span class="title">Enabled</span>
        <strong>{!! $enabled_count !!}<span>/{!! $indexer_count !!}</span></strong>
    </li>
    <li>
        <span class="title">Failed</span>
        <strong>{!! $failure_count !!}</strong>
    </li>
</ul>