<?php namespace App\SupportedApps\Hasura;

class Hasura extends \App\SupportedApps {

}