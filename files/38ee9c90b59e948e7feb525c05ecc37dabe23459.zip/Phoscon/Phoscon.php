<?php namespace App\SupportedApps\Phoscon;

class Phoscon extends \App\SupportedApps {

}