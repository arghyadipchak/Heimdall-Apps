<?php namespace App\SupportedApps\HomeAssistant;

class HomeAssistant extends \App\SupportedApps {

}