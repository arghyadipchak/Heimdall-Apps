<?php namespace App\SupportedApps\Invidious;

class Invidious extends \App\SupportedApps {

}